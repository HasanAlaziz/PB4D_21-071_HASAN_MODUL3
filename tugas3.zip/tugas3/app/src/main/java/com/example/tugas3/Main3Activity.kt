package com.example.tugas3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.view.View
import android.widget.Button
import android.widget.EditText


class Main3Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        val button : Button = findViewById(R.id.button_register)

        fun register(view: View) {
            val name = findViewById<EditText>(R.id.edit_text_name).text.toString()
            val email = findViewById<EditText>(R.id.edit_text_email).text.toString()

            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "text/plain"
            intent.putExtra(Intent.EXTRA_EMAIL, arrayOf("admin@example.com"))
            intent.putExtra(Intent.EXTRA_SUBJECT, "Registration")
            intent.putExtra(Intent.EXTRA_TEXT, "Please register $name with email $email")
            startActivity(Intent.createChooser(intent, "Send Email"))
        }

        button.setOnClickListener { view ->
            register(view)
        }
    }
}

